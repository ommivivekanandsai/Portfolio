export interface Visit {
  date: string;
  count: number;
}

export interface Customer {
  id: string;
  name: string;
  location: string;
  visits: Visit[];
  createdAt: string;
}