import React, { useState, useEffect } from 'react';
import { Truck, Users } from 'lucide-react';
import { Customer } from './types/Customer';
import { getCustomers, updateCustomer, getTodayDate } from './utils/storage';
import { CustomerForm } from './components/CustomerForm';
import { CustomerCard } from './components/CustomerCard';
import { CustomerDetails } from './components/CustomerDetails';

function App() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  useEffect(() => {
    setCustomers(getCustomers());
  }, []);

  const handleCustomerAdded = (newCustomer: Customer) => {
    setCustomers([...customers, newCustomer]);
  };

  const handleAddVisit = (customerId: string) => {
    const today = getTodayDate();
    const customer = customers.find(c => c.id === customerId);
    
    if (!customer) return;

    const updatedCustomer = { ...customer };
    const existingVisit = updatedCustomer.visits.find(v => v.date === today);

    if (existingVisit) {
      existingVisit.count += 1;
    } else {
      updatedCustomer.visits.push({ date: today, count: 1 });
    }

    updateCustomer(updatedCustomer);
    setCustomers(customers.map(c => c.id === customerId ? updatedCustomer : c));
  };

  const handleViewDetails = (customer: Customer) => {
    setSelectedCustomer(customer);
  };

  const closeDetails = () => {
    setSelectedCustomer(null);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-6">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Truck className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Driver's Customer Tracker</h1>
                <p className="text-gray-600 text-sm">Track your daily customer visits</p>
              </div>
            </div>
            <div className="flex items-center space-x-2 text-gray-600">
              <Users className="w-5 h-5" />
              <span className="font-medium">{customers.length} Customer{customers.length !== 1 ? 's' : ''}</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <CustomerForm onCustomerAdded={handleCustomerAdded} />
        
        {customers.length === 0 ? (
          <div className="text-center py-12">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No customers yet</h3>
            <p className="text-gray-600">Add your first customer using the form above</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {customers.map((customer) => (
              <CustomerCard
                key={customer.id}
                customer={customer}
                onAddVisit={handleAddVisit}
                onViewDetails={handleViewDetails}
              />
            ))}
          </div>
        )}
      </main>

      {selectedCustomer && (
        <CustomerDetails
          customer={selectedCustomer}
          onClose={closeDetails}
        />
      )}
    </div>
  );
}

export default App;