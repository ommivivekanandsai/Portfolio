import React from 'react';
import { X, MapPin, Calendar, TrendingUp, Clock } from 'lucide-react';
import { Customer } from '../types/Customer';

interface CustomerDetailsProps {
  customer: Customer;
  onClose: () => void;
}

export const CustomerDetails: React.FC<CustomerDetailsProps> = ({ customer, onClose }) => {
  const totalVisits = customer.visits.reduce((sum, visit) => sum + visit.count, 0);
  const sortedVisits = [...customer.visits].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const isToday = (dateString: string) => {
    const today = new Date().toISOString().split('T')[0];
    return dateString === today;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-hidden">
        <div className="bg-blue-600 text-white p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold mb-1">{customer.name}</h2>
              <div className="flex items-center text-blue-100">
                <MapPin className="w-4 h-4 mr-1" />
                {customer.location}
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:bg-blue-500 p-2 rounded-full transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-blue-50 rounded-lg p-4">
              <div className="flex items-center text-blue-700 mb-2">
                <TrendingUp className="w-5 h-5 mr-2" />
                <span className="font-medium">Total Visits</span>
              </div>
              <div className="text-2xl font-bold text-blue-800">{totalVisits}</div>
            </div>
            
            <div className="bg-purple-50 rounded-lg p-4">
              <div className="flex items-center text-purple-700 mb-2">
                <Calendar className="w-5 h-5 mr-2" />
                <span className="font-medium">Days Visited</span>
              </div>
              <div className="text-2xl font-bold text-purple-800">{customer.visits.length}</div>
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
              <Clock className="w-5 h-5 mr-2" />
              Visit History
            </h3>
            
            {sortedVisits.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Calendar className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>No visits recorded yet</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-60 overflow-y-auto">
                {sortedVisits.map((visit, index) => (
                  <div
                    key={visit.date}
                    className={`flex items-center justify-between p-3 rounded-lg border ${
                      isToday(visit.date)
                        ? 'bg-green-50 border-green-200'
                        : 'bg-gray-50 border-gray-200'
                    }`}
                  >
                    <div className="flex items-center">
                      {isToday(visit.date) && (
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      )}
                      <div>
                        <div className={`font-medium ${
                          isToday(visit.date) ? 'text-green-800' : 'text-gray-800'
                        }`}>
                          {formatDate(visit.date)}
                        </div>
                        {isToday(visit.date) && (
                          <div className="text-sm text-green-600">Today</div>
                        )}
                      </div>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                      isToday(visit.date)
                        ? 'bg-green-100 text-green-800'
                        : 'bg-gray-100 text-gray-700'
                    }`}>
                      {visit.count} visit{visit.count !== 1 ? 's' : ''}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};