import React from 'react';
import { Plus, MapPin, Calendar, TrendingUp } from 'lucide-react';
import { Customer, Visit } from '../types/Customer';
import { getTodayDate } from '../utils/storage';

interface CustomerCardProps {
  customer: Customer;
  onAddVisit: (customerId: string) => void;
  onViewDetails: (customer: Customer) => void;
}

export const CustomerCard: React.FC<CustomerCardProps> = ({ 
  customer, 
  onAddVisit, 
  onViewDetails 
}) => {
  const today = getTodayDate();
  const todayVisit = customer.visits.find(v => v.date === today);
  const totalVisits = customer.visits.reduce((sum, visit) => sum + visit.count, 0);
  const totalDays = customer.visits.length;

  const handleAddVisit = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddVisit(customer.id);
  };

  const handleCardClick = () => {
    onViewDetails(customer);
  };

  return (
    <div 
      onClick={handleCardClick}
      className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow cursor-pointer border border-gray-200"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-800 mb-1">{customer.name}</h3>
          <div className="flex items-center text-gray-600 text-sm">
            <MapPin className="w-4 h-4 mr-1" />
            {customer.location}
          </div>
        </div>
        
        <button
          onClick={handleAddVisit}
          className="bg-green-600 hover:bg-green-700 text-white p-2 rounded-full transition-colors shadow-sm hover:shadow-md"
          title="Add visit for today"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4 text-sm">
        <div className="flex items-center">
          <TrendingUp className="w-4 h-4 text-blue-600 mr-2" />
          <span className="text-gray-600">Total Visits:</span>
          <span className="font-semibold ml-1">{totalVisits}</span>
        </div>
        
        <div className="flex items-center">
          <Calendar className="w-4 h-4 text-purple-600 mr-2" />
          <span className="text-gray-600">Days:</span>
          <span className="font-semibold ml-1">{totalDays}</span>
        </div>
      </div>

      {todayVisit && (
        <div className="mt-3 bg-green-50 border border-green-200 rounded-md p-2">
          <div className="flex items-center text-green-700 text-sm">
            <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
            Visited today: {todayVisit.count} time{todayVisit.count !== 1 ? 's' : ''}
          </div>
        </div>
      )}
    </div>
  );
};